USE [master]
GO
-- 0. Xóa Database EventManagement nếu đã tồn tại trong DBMS --------------------
IF EXISTS (
    SELECT name 
    FROM sys.databases 
    WHERE name = N'EventManagement'
)
BEGIN
    -- Tùy chọn: đưa DB về SINGLE_USER để tránh lỗi đang có kết nối
    ALTER DATABASE [EventManagement] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    
    -- Xóa database
    DROP DATABASE [EventManagement];
END
GO

/****** Object:  Database [EventManagement]    Script Date: 01/13/2025 04:45:35 ******/
CREATE DATABASE [EventManagement]
GO

USE [EventManagement]
GO

-- Tạo table Accounts ----------------------------------------------------------------
CREATE TABLE [dbo].[Accounts] (
    [account] [varchar](50) NOT NULL,			-- A member account used for system login 
    [fullName] [nvarchar](100) NOT NULL,		-- Full name of the member, who was created account in system
	[gender] [bit] not null default 1 ,			-- Gender of the member: 0:Female - 1: Male
    [password] [varchar](50) NOT NULL,			-- Password uses to login system
	[activated] [bit] default 0,				-- Status of the account: 0 [inactive] - 1 [Active]
    CONSTRAINT [PK_Accounts] PRIMARY KEY CLUSTERED 
    ([account] ASC)
)
GO
-- Tạo table Events ----------------------------------------------------------------
CREATE TABLE [dbo].[Events] (

    [eventId] [char](5) NOT NULL,				-- Id of the event
    [eventName] [nvarchar](80) NOT NULL,		-- Name of event 
    [location] [nvarchar](250) NOT NULL,		-- The Location, venue for the event
    [eventDate] [datetime] NOT NULL,			-- The event date
    [price] [float] NOT NULL,					-- Ticket price
    [availableSeats] [int] NOT NULL,			-- The number of seats available for the event
    CONSTRAINT [PK_Events] PRIMARY KEY CLUSTERED 
    ([eventId] ASC)
    
)
GO

-- Input data to all of table ----------------------------------------------------------------------------------------
INSERT [dbo].[Accounts] ([account], [fullName], [gender], [password], [activated]) VALUES (N'manager', N'John Doe',1, N'123',1);
INSERT [dbo].[Accounts] ([account], [fullName], [gender], [password], [activated]) VALUES (N'Jane', N'Jane Smith',1, N'111',1);
INSERT [dbo].[Accounts] ([account], [fullName], [gender], [password], [activated]) VALUES (N'Oliver', N'Oliver Andrew',1, N'222',0);
INSERT [dbo].[Accounts] ([account], [fullName], [gender], [password], [activated]) VALUES (N'Akshita', N'Akshita Bush',0, N'333',1);
INSERT [dbo].[Accounts] ([account], [fullName], [gender], [password], [activated]) VALUES (N'Bridget', N'Bridget Bernard',0, N'123',0);
INSERT [dbo].[Accounts] ([account], [fullName], [gender], [password], [activated]) VALUES (N'Liam', N'Liam Boniface',1, N'222',1);
INSERT [dbo].[Accounts] ([account], [fullName], [gender], [password], [activated]) VALUES (N'Benjamin', N'Benjamin Derek',1, N'432',0);
INSERT [dbo].[Accounts] ([account], [fullName], [gender], [password], [activated]) VALUES (N'Leo', N'Leo Christopher',1, N'112',1);
INSERT [dbo].[Accounts] ([account], [fullName], [gender], [password], [activated]) VALUES (N'Max', N'Max  Dominic',1, N'321',0);
INSERT [dbo].[Accounts] ([account], [fullName], [gender], [password], [activated]) VALUES (N'Celina', N'Celina Douglas',0, N'123',0);
INSERT [dbo].[Accounts] ([account], [fullName], [gender], [password], [activated]) VALUES (N'Felicity', N'Felicity Erasmus',0, N'567',1);
INSERT [dbo].[Accounts] ([account], [fullName], [gender], [password], [activated]) VALUES (N'Genevieve', N'Genevieve Smith',0, N'1',1);
go

INSERT [dbo].[Events] ([eventId], [eventName], [location], [eventDate], [price], [availableSeats]) 
VALUES (N'E0001', N'Conference', N'New York', '2025-12-15 9:30:05', 200.00, 50);
INSERT [dbo].[Events] ([eventId], [eventName], [location], [eventDate], [price], [availableSeats]) 
VALUES (N'E0002', N'Music Festival', N'Paris', '2025-12-24 20:15:00', 150.00, 500);
INSERT [dbo].[Events] ([eventId], [eventName], [location], [eventDate], [price], [availableSeats]) 
VALUES (N'E0003', N'Reunification Day Fair', N'Toronto', '2026-01-25 9:00:00', 315.00, 350);
INSERT [dbo].[Events] ([eventId], [eventName], [location], [eventDate], [price], [availableSeats]) 
VALUES (N'E0004', N'Summer Festival', N'Los Angeles', '2026-02-20 11:30:00', 225.00, 1000);
INSERT [dbo].[Events] ([eventId], [eventName], [location], [eventDate], [price], [availableSeats]) 
VALUES (N'E0006', N'Nationwide Singing Contest', N'Kyoto', '2026-04-22 19:45:00', 350.00, 1500);
INSERT [dbo].[Events] ([eventId], [eventName], [location], [eventDate], [price], [availableSeats]) 
VALUES (N'E0007', N'Southeast Asian MMA Tournament', N'Bangkok', '2026-04-25 18:35:00', 275.00, 550);
INSERT [dbo].[Events] ([eventId], [eventName], [location], [eventDate], [price], [availableSeats]) 
VALUES (N'E0008', N'Music Celebration Festival', N'Ho Chi Minh City', '2026-04-30 20:00:00', 205.00, 10000);
INSERT [dbo].[Events] ([eventId], [eventName], [location], [eventDate], [price], [availableSeats]) 
VALUES (N'E0005', N'International Labour Day', N'Ha Noi', '2026-05-01 8:30:00', 186.00, 500);
INSERT [dbo].[Events] ([eventId], [eventName], [location], [eventDate], [price], [availableSeats]) 
VALUES (N'E0009', N'Conference', N'New York', '2026-05-02 14:30:00', 320.00, 500);
INSERT [dbo].[Events] ([eventId], [eventName], [location], [eventDate], [price], [availableSeats]) 
VALUES (N'E0010', N'Prestigious Award for Singers and Musicians 2025', N'Los Angeles', '2026-05-29 21:15:00', 415.00, 1500);
go